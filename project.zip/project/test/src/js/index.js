console.log($);
console.log('test');